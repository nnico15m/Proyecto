-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 25-11-2014 a las 23:31:42
-- Versión del servidor: 5.0.51
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `futbol3`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `amigos`
-- 

CREATE TABLE `amigos` (
  `id` int(10) NOT NULL auto_increment,
  `jugador_id` int(10) unsigned NOT NULL,
  `jugador2` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `jugador1` (`jugador_id`,`jugador2`),
  KEY `jugador2` (`jugador2`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `amigos`
-- 

INSERT INTO `amigos` VALUES (1, 1, 2);
INSERT INTO `amigos` VALUES (2, 1, 3);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `calificaciones`
-- 

CREATE TABLE `calificaciones` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `jugador_id` int(10) unsigned NOT NULL,
  `partido_id` int(10) unsigned NOT NULL,
  `nota` int(10) unsigned NOT NULL,
  `descripcion` varchar(100) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `idJugador` (`jugador_id`,`partido_id`),
  KEY `idPartido` (`partido_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=7 ;

-- 
-- Volcar la base de datos para la tabla `calificaciones`
-- 

INSERT INTO `calificaciones` VALUES (1, 1, 1, 6, 'jugo bien');
INSERT INTO `calificaciones` VALUES (2, 1, 1, 8, 'genial');
INSERT INTO `calificaciones` VALUES (3, 2, 2, 4, 'mal');
INSERT INTO `calificaciones` VALUES (4, 2, 2, 2, 'muy mal');
INSERT INTO `calificaciones` VALUES (5, 1, 2, 8, 'grande');
INSERT INTO `calificaciones` VALUES (6, 1, 2, 9, 'groso');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `comunidades`
-- 

CREATE TABLE `comunidades` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `idAdministrador` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `idAdministrador` (`idAdministrador`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `comunidades`
-- 

INSERT INTO `comunidades` VALUES (1, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `infracciones`
-- 

CREATE TABLE `infracciones` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `jugador_id` int(10) unsigned NOT NULL,
  `motivo` varchar(100) collate utf8_spanish_ci NOT NULL,
  `fecha` date NOT NULL,
  `duracion` double NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `idJugador` (`jugador_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=7 ;

-- 
-- Volcar la base de datos para la tabla `infracciones`
-- 

INSERT INTO `infracciones` VALUES (3, 1, 'muerto', '2014-11-16', 4);
INSERT INTO `infracciones` VALUES (4, 1, 'falto', '2014-11-12', 6);
INSERT INTO `infracciones` VALUES (5, 14, 'muerto', '2014-11-16', 2);
INSERT INTO `infracciones` VALUES (6, 9, 'mal perdedor', '2014-11-17', 6);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `inscripciones`
-- 

CREATE TABLE `inscripciones` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `jugador_id` int(10) unsigned NOT NULL,
  `partido_id` int(10) unsigned NOT NULL,
  `inscripcion_id` int(10) unsigned NOT NULL,
  `equipo_id` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idJugador` (`jugador_id`,`partido_id`,`inscripcion_id`),
  KEY `idPartido` (`partido_id`),
  KEY `idTipoeInscripcion` (`inscripcion_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=32 ;

-- 
-- Volcar la base de datos para la tabla `inscripciones`
-- 

INSERT INTO `inscripciones` VALUES (4, 1, 1, 1, 2);
INSERT INTO `inscripciones` VALUES (5, 2, 1, 1, 0);
INSERT INTO `inscripciones` VALUES (6, 2, 2, 1, 0);
INSERT INTO `inscripciones` VALUES (7, 3, 1, 1, 1);
INSERT INTO `inscripciones` VALUES (8, 4, 1, 1, 1);
INSERT INTO `inscripciones` VALUES (9, 5, 1, 1, 2);
INSERT INTO `inscripciones` VALUES (10, 6, 1, 1, 2);
INSERT INTO `inscripciones` VALUES (11, 4, 2, 1, 0);
INSERT INTO `inscripciones` VALUES (12, 5, 2, 1, 0);
INSERT INTO `inscripciones` VALUES (13, 6, 3, 1, 2);
INSERT INTO `inscripciones` VALUES (14, 4, 3, 1, 1);
INSERT INTO `inscripciones` VALUES (16, 3, 4, 1, 0);
INSERT INTO `inscripciones` VALUES (17, 5, 3, 1, 2);
INSERT INTO `inscripciones` VALUES (18, 2, 4, 1, 0);
INSERT INTO `inscripciones` VALUES (19, 13, 1, 1, 2);
INSERT INTO `inscripciones` VALUES (20, 12, 1, 1, 0);
INSERT INTO `inscripciones` VALUES (21, 8, 1, 1, 1);
INSERT INTO `inscripciones` VALUES (22, 7, 1, 1, 1);
INSERT INTO `inscripciones` VALUES (23, 14, 1, 1, 2);
INSERT INTO `inscripciones` VALUES (24, 15, 1, 1, 2);
INSERT INTO `inscripciones` VALUES (25, 14, 3, 1, 1);
INSERT INTO `inscripciones` VALUES (26, 12, 3, 1, 2);
INSERT INTO `inscripciones` VALUES (27, 9, 3, 1, 1);
INSERT INTO `inscripciones` VALUES (28, 7, 3, 3, 2);
INSERT INTO `inscripciones` VALUES (29, 10, 3, 1, 1);
INSERT INTO `inscripciones` VALUES (30, 5, 3, 1, 0);
INSERT INTO `inscripciones` VALUES (31, 4, 3, 1, 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `jugadores`
-- 

CREATE TABLE `jugadores` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `nombre` varchar(30) collate utf8_spanish_ci NOT NULL,
  `apodo` varchar(15) collate utf8_spanish_ci NOT NULL,
  `nivelDeJuego` int(10) unsigned NOT NULL default '0',
  `fechaDeNacimiento` date NOT NULL,
  `comunidad_id` int(10) unsigned NOT NULL default '0',
  `promediocalif` int(10) NOT NULL default '0',
  `promedioultpart` int(10) NOT NULL default '0',
  `promediovarios` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `comunidad_id` (`comunidad_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=16 ;

-- 
-- Volcar la base de datos para la tabla `jugadores`
-- 

INSERT INTO `jugadores` VALUES (1, 'p1', 'p1', 4, '1991-01-01', 1, 3, 5, 4);
INSERT INTO `jugadores` VALUES (2, 'p2', 'p2', 8, '1997-11-07', 1, 6, 7, 8);
INSERT INTO `jugadores` VALUES (3, 'p3', 'p3', 7, '1990-11-15', 1, 7, 2, 1);
INSERT INTO `jugadores` VALUES (4, 'p4', 'p4', 4, '1995-11-09', 1, 2, 7, 9);
INSERT INTO `jugadores` VALUES (5, 'p5', 'p5', 8, '1991-02-11', 1, 5, 4, 3);
INSERT INTO `jugadores` VALUES (6, 'p6', 'p6', 4, '1995-11-09', 1, 6, 9, 2);
INSERT INTO `jugadores` VALUES (7, 'p7', 'p7', 5, '1990-02-16', 1, 4, 6, 7);
INSERT INTO `jugadores` VALUES (8, 'p8', 'p8', 6, '1995-11-02', 1, 9, 6, 5);
INSERT INTO `jugadores` VALUES (9, 'p9', 'p9', 7, '1991-02-09', 1, 6, 6, 3);
INSERT INTO `jugadores` VALUES (10, 'p10', 'p10', 4, '1996-11-08', 1, 4, 6, 7);
INSERT INTO `jugadores` VALUES (11, 'p11', 'p11', 8, '1991-02-09', 1, 3, 6, 4);
INSERT INTO `jugadores` VALUES (12, 'p12', 'p12', 7, '2014-02-12', 1, 6, 5, 8);
INSERT INTO `jugadores` VALUES (13, 'p13', 'p13', 6, '1995-11-09', 1, 2, 6, 5);
INSERT INTO `jugadores` VALUES (14, 'p14', 'p14', 9, '1990-11-15', 1, 6, 8, 5);
INSERT INTO `jugadores` VALUES (15, 'p15', 'p15', 6, '1991-02-09', 0, 8, 6, 5);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `notasderechazo`
-- 

CREATE TABLE `notasderechazo` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `idJugador` int(10) unsigned NOT NULL,
  `fecha` date NOT NULL,
  `motivo` varchar(100) collate utf8_spanish_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `idJugador` (`idJugador`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `notasderechazo`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `partidos`
-- 

CREATE TABLE `partidos` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `fechayhora` datetime default NULL,
  `comunidad_id` int(10) unsigned default NULL,
  `criterioOrdenamiento` int(10) unsigned NOT NULL default '1',
  `criterioDivision` int(10) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `idComunidad` (`comunidad_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=6 ;

-- 
-- Volcar la base de datos para la tabla `partidos`
-- 

INSERT INTO `partidos` VALUES (1, NULL, NULL, 4, 2);
INSERT INTO `partidos` VALUES (2, NULL, NULL, 1, 2);
INSERT INTO `partidos` VALUES (3, NULL, NULL, 2, 1);
INSERT INTO `partidos` VALUES (4, NULL, NULL, 2, 1);
INSERT INTO `partidos` VALUES (5, NULL, NULL, 4, 2);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `pendientedecalificar`
-- 

CREATE TABLE `pendientedecalificar` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `jugador` int(10) unsigned NOT NULL,
  `aCalificar` int(10) unsigned NOT NULL,
  `jugador_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `jugador` (`jugador`,`aCalificar`),
  KEY `aCalificar` (`aCalificar`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `pendientedecalificar`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tiposdeinscripcion`
-- 

CREATE TABLE `tiposdeinscripcion` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `tipo` varchar(15) collate utf8_spanish_ci NOT NULL,
  `prioridad` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=4 ;

-- 
-- Volcar la base de datos para la tabla `tiposdeinscripcion`
-- 

INSERT INTO `tiposdeinscripcion` VALUES (1, '1', 1);
INSERT INTO `tiposdeinscripcion` VALUES (2, '2', 2);
INSERT INTO `tiposdeinscripcion` VALUES (3, '3', 3);

-- 
-- Filtros para las tablas descargadas (dump)
-- 

-- 
-- Filtros para la tabla `amigos`
-- 
ALTER TABLE `amigos`
  ADD CONSTRAINT `amigos_ibfk_1` FOREIGN KEY (`jugador_id`) REFERENCES `jugadores` (`id`);

-- 
-- Filtros para la tabla `calificaciones`
-- 
ALTER TABLE `calificaciones`
  ADD CONSTRAINT `calificaciones_ibfk_1` FOREIGN KEY (`jugador_id`) REFERENCES `jugadores` (`id`),
  ADD CONSTRAINT `calificaciones_ibfk_2` FOREIGN KEY (`partido_id`) REFERENCES `partidos` (`id`);

-- 
-- Filtros para la tabla `comunidades`
-- 
ALTER TABLE `comunidades`
  ADD CONSTRAINT `comunidades_ibfk_1` FOREIGN KEY (`idAdministrador`) REFERENCES `jugadores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `comunidades_ibfk_2` FOREIGN KEY (`id`) REFERENCES `jugadores` (`id`);

-- 
-- Filtros para la tabla `infracciones`
-- 
ALTER TABLE `infracciones`
  ADD CONSTRAINT `infracciones_ibfk_1` FOREIGN KEY (`jugador_id`) REFERENCES `jugadores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `inscripciones`
-- 
ALTER TABLE `inscripciones`
  ADD CONSTRAINT `inscripciones_ibfk_1` FOREIGN KEY (`jugador_id`) REFERENCES `jugadores` (`id`),
  ADD CONSTRAINT `inscripciones_ibfk_2` FOREIGN KEY (`partido_id`) REFERENCES `partidos` (`id`),
  ADD CONSTRAINT `inscripciones_ibfk_3` FOREIGN KEY (`inscripcion_id`) REFERENCES `tiposdeinscripcion` (`id`);

-- 
-- Filtros para la tabla `jugadores`
-- 
ALTER TABLE `jugadores`
  ADD CONSTRAINT `FK_cnioupc49fcowl7wdjsdxnujb` FOREIGN KEY (`id`) REFERENCES `jugadores` (`id`);

-- 
-- Filtros para la tabla `notasderechazo`
-- 
ALTER TABLE `notasderechazo`
  ADD CONSTRAINT `notasderechazo_ibfk_1` FOREIGN KEY (`idJugador`) REFERENCES `jugadores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Filtros para la tabla `partidos`
-- 
ALTER TABLE `partidos`
  ADD CONSTRAINT `partidos_ibfk_1` FOREIGN KEY (`comunidad_id`) REFERENCES `comunidades` (`id`);

-- 
-- Filtros para la tabla `pendientedecalificar`
-- 
ALTER TABLE `pendientedecalificar`
  ADD CONSTRAINT `pendientedecalificar_ibfk_1` FOREIGN KEY (`jugador`) REFERENCES `jugadores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pendientedecalificar_ibfk_2` FOREIGN KEY (`aCalificar`) REFERENCES `jugadores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
